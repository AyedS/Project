<!DOCTYPE html>
<?php require '../FCT/FCT.php';
  session_start(); ?>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../style/style.css">
    <script src="js/script.js"></script>
    <title>Adopt Your Job</title>
  </head>

  <body>


      
    <?php topnav(); ?>

<!------>



<div class="e">
<div id="mapproj">
<MAP name="map1">
<?php getRegion(); ?>
</MAP>
</div>
<IMG SRC="../images/France.png" USEMAP="#map1" />
</div>

 
  <div class="footer">
    <div class="row2">
      <div class="a"><h3>Consultez</h3><p>Statistique, avis & entreprise</p></div>
      <div class="b"><h3>Partagez</h3><p>Votre experiance & formation</p></div>
      <div class="c"><h3>Adoptez</h3><p>Votre avenir profesionnel !</p></div>
    </div>
  </div>
  </body>
</html>
