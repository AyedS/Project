<?php
    
include('../fct/FCT.php');





if($_POST['prenom'] == "" or $_POST['nom'] == "" or $_POST['mail'] == "" or $_POST['mdp1'] != $_POST['mdp2']){
    echo '<meta http-equiv="refresh" content="1; URL=../client/inscription.php?prenom='.$_POST['prenom'].'&nom='.$_POST['nom'].'&mail='.$_POST['mail'].'&num='.$_POST['num'].'">';
}
else{
    if($_POST['num'] != ""){
        envoi_inscr($_POST['prenom'],$_POST['nom'],$_POST['mail'],$_POST['num'],$_POST['mdp1']);
        echo '<meta http-equiv="refresh" content="1; URL=../client/inscription.php?ok=ok">';
    }
    else{
        envoi2_inscr($_POST['prenom'],$_POST['nom'],$_POST['mail'],$_POST['mdp1']);
        echo '<meta http-equiv="refresh" content="1; URL=../client/inscription.php?ok=ok">';
    }
}

?>