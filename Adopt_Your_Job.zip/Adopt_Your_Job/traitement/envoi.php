<?php
include('../fct/FCT.php');






if($_POST['prenom'] == "" or $_POST['nom'] == "" or $_POST['mail'] == "" or $_POST['message'] == ""){
      echo '<meta http-equiv="refresh" content="1; URL=../client/contact.php?prenom='.$_POST['prenom'].'&nom='.$_POST['nom'].'&mail='.$_POST['mail'].'&message='.$_POST['message'].'">';
}
else{
    if($_POST['num'] != ""){
        envoi_envoi($_POST['prenom'],$_POST['nom'],$_POST['mail'],$_POST['num'],$_POST['message']);
        echo '<meta http-equiv="refresh" content="1; URL=../client/contact.php?ok=ok">';
    }
    
    if($_POST['num'] == ""){
        envoi2_envoi($_POST['prenom'],$_POST['nom'],$_POST['mail'],$_POST['message']);
        echo '<meta http-equiv="refresh" content="1; URL=../client/contact.php?ok=ok">';
    }
}

?>