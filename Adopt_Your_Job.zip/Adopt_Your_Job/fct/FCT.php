<?php
function getBD(){
    $bdd=new PDO('mysql:host=127.0.0.1;dbname=adopt_your_job;charset=utf8','root','');
    return $bdd;
}

function getRegion(){
    $bd=getBD();
    $reg=$bd -> query('SELECT * FROM regions');
  
    while($region=$reg->fetch()){
        echo '<AREA id=hover ';
        echo 'HREF="region.php?reg='.$region['ID'].'" ';
        echo 'SHAPE="poly" ';
        echo 'ALT="'.$region['title_alt'].'" ';
        echo' TITLE="'.$region['title_alt'].'" ';
        echo 'COORDS=" '.$region['coords'].'" ';
        echo '/> ';
        echo '<br/>';
    }
}
function topnav(){
    if(isset($_SESSION['client'])){
        echo '<div class="topnav">
        <div class="conn"><a href="../traitement/deco.php">Deconnexion</a></div>
        <div class="con"><a href="../client/contact.php">Contact</a></div>
        <div class="ins"><a href="../client/inscription.php">Inscription</a></div>
        <div class="rec"><a href="#Recherche">Recherche</a></div>
        <div class="acc"><a href="../index/index.php">Accueil</a></div>
        <div class="logo"><img src="../images/logo1.png"></div>
        <div class="titre">Adopt your job</div>  
        </div> ';
    }
    else{
        echo '<div class="topnav">
        <div class="conn"><a href="../client/connexion.php">Connexion</a></div>
        <div class="con"><a href="../client/contact.php">Contact</a></div>
        <div class="ins"><a href="../client/inscription.php">Inscription</a></div>
        <div class="rec"><a href="#Recherche">Recherche</a></div>
        <div class="acc"><a href="../index/index.php">Accueil</a></div>
        <div class="logo"><img src="../images/logo1.png"></div>
        <div class="titre">Adopt your job</div>  
        </div> ';
    }
}
function envoi_inscr($prenom,$nom,$email,$numero, $mdp){
    $database2 = getBD();
    $results = $database2 -> query("INSERT INTO utilisateur (prenom,nom,email,numero,mdp) VALUES('".$prenom."','".$nom ."','".$email."','".$numero."','".$mdp."')");
    return $results;
}

function envoi2_inscr($prenom,$nom,$email, $mdp){
    $database2 = getBD();
    $results = $database2 -> query("INSERT INTO utilisateur (prenom,nom,email,mdp) VALUES('".$prenom."','".$nom ."','".$email."','".$mdp."')");
    return $results;
}
function envoi_envoi($prenom,$nom,$email,$numero, $message){
    $database1 = getBD();
    $results = $database1 -> query("INSERT INTO contact (prenom,nom,email,numero,message) VALUES('".$prenom."','".$nom ."','".$email."','".$numero."','".$message."')");
    return $results;
}

function envoi2_envoi($prenom,$nom,$email, $message){
    $database1 = getBD();
    $results = $database1 -> query("INSERT INTO contact (prenom,nom,email,message) VALUES('".$prenom."','".$nom ."','".$email."','".$message."')");
    return $results;
}
?>