<!DOCTYPE html>
<?php require 'FCT.php'; ?>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/script.js"></script>
    <title>Adopt Your Job</title>
  </head>

  <body>


      <div class="topnav">
          <div class="conn"><a href="#Connexion">Connexion</a></div>
          <div class="con"><a href="contact/contact.php">Contact</a></div>
          <div class="ins"><a href="#Inscription">Inscription</a></div>
          <div class="rec"><a href="#Recherche">Recherche</a></div>
          <div class="acc"><a href="index.html">Accueil</a></div>
          <div class="logo"><img src="images/logo1.png"></div>
          <div class="titre">Adopt your job</div>  
      </div>

<!------>



<div class="e">
<div id="mapproj">
<MAP name="map1">
<?php getRegion(); ?>
</MAP>
</div>
<IMG SRC="images/France.png" USEMAP="#map1" />
</div>

 
  <div class="footer">
    <div class="row2">
      <div class="a"><h3>Consultez</h3><p>Statistique, avis & entreprise</p></div>
      <div class="b"><h3>Partagez</h3><p>Votre experiance & formation</p></div>
      <div class="c"><h3>Adoptez</h3><p>Votre avenir profesionnel !</p></div>
    </div>
  </div>
  </body>
</html>
