<?php
function getBD(){
    $bdd=new PDO('mysql:host=127.0.0.1;dbname=region;charset=utf8','root','');
    return $bdd;
}
function getRegion(){
    $bd=getBD();
    $reg=$bd -> query('SELECT * FROM regions');
  
    while($region=$reg->fetch()){
        echo '<AREA ';
        echo 'HREF="region.php?reg='.$region['ID'].'" ';
        echo 'SHAPE="poly" ';
        echo 'ALT="'.$region['title_alt'].'" ';
        echo' TITLE="'.$region['title_alt'].'" ';
        echo 'COORDS=" '.$region['coords'].'" ';
        echo '/> ';
        echo '<br/>';
    }
}
?>