using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Region
{
    #region Regions
    public class Regions
    {
        #region Member Variables
        protected int _ID;
        protected string _title_alt;
        protected string _coords;
        #endregion
        #region Constructors
        public Regions() { }
        public Regions(string title_alt, string coords)
        {
            this._title_alt=title_alt;
            this._coords=coords;
        }
        #endregion
        #region Public Properties
        public virtual int ID
        {
            get {return _ID;}
            set {_ID=value;}
        }
        public virtual string Title_alt
        {
            get {return _title_alt;}
            set {_title_alt=value;}
        }
        public virtual string Coords
        {
            get {return _coords;}
            set {_coords=value;}
        }
        #endregion
    }
    #endregion
}